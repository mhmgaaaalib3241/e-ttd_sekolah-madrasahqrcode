<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/verify/(:segment)', 'Verify::index/$1');
$routes->get('/', 'Auth::index');
$routes->post('/auth/process', 'Auth::process');
$routes->get('/logout', 'Auth::logout');
$routes->get('/verify/(:segment)', 'Home::verify/$1'); // Cek Keaslian


// Halaman yang butuh Login
$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('/dashboard', 'Dashboard::index');
    
    // Users
    $routes->get('/users', 'Users::index');
    $routes->post('/users/add', 'Users::store');

    // Berkas
    $routes->get('/documents', 'Documents::index');
    $routes->post('/documents/upload', 'Documents::upload');
    $routes->get('documents/delete/(:num)', 'Documents::delete/$1');
    $routes->post('documents/update', 'Documents::update');
    
        // Proses TTD
    $routes->get('documents/cancel/(:num)', 'Documents::cancel_sign/$1');
    $routes->get('/documents/sign/(:num)', 'Signature::editor/$1');
    $routes->post('/signature/generate_qr', 'Signature::generate_qr');
    $routes->post('/signature/save_position', 'Signature::save_position');
    
    // Download
    $routes->get('/documents/download/(:any)', 'Documents::download/$1');
    
    // User
    $routes->get('/users', 'Users::index');
    $routes->post('/users/store', 'Users::store');
    $routes->post('/users/update', 'Users::update');
    $routes->get('/users/delete/(:num)', 'Users::delete/$1');
    
    // Pengaturan
    $routes->get('/settings', 'Settings::index');
    $routes->post('/settings/update', 'Settings::update');
        
});