<?php namespace App\Controllers;
use App\Models\UserModel;

class Auth extends BaseController {
    public function index() {
        return view('login');
    }

    public function process() {
        $model = new UserModel();
        $user = $model->where('username', $this->request->getVar('username'))->first();
        
        if ($user && password_verify($this->request->getVar('password'), $user['password'])) {
            session()->set([
                'id' => $user['id'],
                'nama' => $user['nama_lengkap'],
                'logged_in' => true
            ]);
            return redirect()->to('/dashboard');
        }
        return redirect()->back()->with('error', 'Username/Password Salah');
    }

    public function logout() {
        session()->destroy();
        return redirect()->to('/');
    }
}