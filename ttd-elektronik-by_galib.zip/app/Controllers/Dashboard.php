<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\DocumentModel;
use App\Models\SignatureModel;

class Dashboard extends BaseController
{
    public function index()
    {
        // 1. Panggil Semua Model
        $userModel = new UserModel();
        $docModel  = new DocumentModel();
        $sigModel  = new SignatureModel();

        // 2. Hitung Data untuk Statistik
        $data = [
            'title'       => 'Dashboard Utama',
            'count_users' => $userModel->countAllResults(), // Hitung total user
            'count_docs'  => $docModel->countAllResults(),  // Hitung total dokumen
            'count_ttd'   => $sigModel->countAllResults(),  // Hitung total TTD generated
            
            // Hitung dokumen yang belum di TTD (Status Pending)
            'pending_docs'=> $docModel->where('status', 'pending')->countAllResults()
        ];

        // 3. Tampilkan ke View
        return view('dashboard', $data);
    }
}