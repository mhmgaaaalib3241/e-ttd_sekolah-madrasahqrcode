<?php namespace App\Controllers;
use App\Models\DocumentModel;
use App\Models\SignatureModel;

class Documents extends BaseController {
    public function index() {
        $model = new DocumentModel();
        $data['docs'] = $model->findAll();
        return view('documents/index', $data);
    }

    public function upload() {
        $file = $this->request->getFile('berkas');
        if ($file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('uploads/original', $newName);
            
            $model = new DocumentModel();
            $model->save([
                'nomor_surat' => $this->request->getVar('nomor_surat'),
                'nama_berkas' => $this->request->getVar('nama_berkas'),
                'tanggal_berkas' => $this->request->getVar('tanggal_berkas'),
                'uploader_name' => session()->get('nama'),
                'file_path' => $newName
            ]);
        }
        return redirect()->to('/documents');
    }
    
    // --- FITUR BARU ---

    // 1. Hapus Dokumen (Data & File Fisik)
    public function delete($id) {
        $model = new DocumentModel();
        $doc = $model->find($id);

        if ($doc) {
            // Hapus File Asli
            $fileAsli = FCPATH . 'uploads/original/' . $doc['file_path'];
            if (file_exists($fileAsli)) unlink($fileAsli);

            // Hapus File Signed (Jika ada)
            if ($doc['signed_file_path']) {
                $fileSigned = FCPATH . 'uploads/signed/' . $doc['signed_file_path'];
                if (file_exists($fileSigned)) unlink($fileSigned);
            }

            // Hapus Data Database
            $model->delete($id);
            return redirect()->back()->with('success', 'Dokumen berhasil dihapus.');
        }
        return redirect()->back()->with('error', 'Dokumen tidak ditemukan.');
    }

    // 2. Proses Edit Data (Hanya Metadata)
    public function update() {
        $id = $this->request->getVar('id');
        $model = new DocumentModel();
        $doc = $model->find($id);

        // Validasi: Jika sudah Signed, TOLAK EDIT
        if ($doc['status'] == 'signed') {
            return redirect()->back()->with('error', 'Dokumen sudah ditandatangani! Batalkan TTD dulu jika ingin mengedit.');
        }

        $model->update($id, [
            'nomor_surat' => $this->request->getVar('nomor_surat'),
            'nama_berkas' => $this->request->getVar('nama_berkas'),
            'tanggal_berkas' => $this->request->getVar('tanggal_berkas'),
        ]);

        return redirect()->back()->with('success', 'Data dokumen berhasil diperbarui.');
    }

    // 3. Batalkan TTD (Rollback ke Pending + Hapus QR & PDF)
    public function cancel_sign($id) {
        $model = new DocumentModel();
        $sigModel = new SignatureModel(); // Panggil Model Signature
        
        $doc = $model->find($id);

        if ($doc && $doc['status'] == 'signed') {
            
            // A. HAPUS FILE PDF HASIL TTD (Di folder uploads/signed)
            if ($doc['signed_file_path']) {
                $fileSigned = FCPATH . 'uploads/signed/' . $doc['signed_file_path'];
                if (file_exists($fileSigned)) {
                    unlink($fileSigned);
                }
            }

            // B. HAPUS FILE QR CODE IMAGE (Di folder uploads/qr)
            // Kita cari dulu hash-nya di tabel signatures berdasarkan ID Dokumen
            $signature = $sigModel->where('document_id', $id)->first();
            
            if ($signature) {
                // Nama file QR adalah HASH + .png
                $qrFile = FCPATH . 'uploads/qr/' . $signature['unique_hash'] . '.png';
                
                if (file_exists($qrFile)) {
                    unlink($qrFile); // Hapus gambar QR
                }

                // Hapus data dari tabel signatures
                $sigModel->delete($signature['id']);
            }

            // C. RESET STATUS DOKUMEN KE PENDING
            $model->update($id, [
                'status' => 'pending',
                'signed_file_path' => null
            ]);

            return redirect()->back()->with('success', 'Tanda tangan dibatalkan. File PDF Signed dan QR Code telah dihapus.');
        }

        return redirect()->back()->with('error', 'Gagal membatalkan TTD.');
    }
}