<?php namespace App\Controllers;

use App\Models\SettingsModel;

class Settings extends BaseController
{
    public function index()
    {
        $model = new SettingsModel();
        // Ambil data ID 1 (karena pengaturan cuma ada 1 baris)
        $data = [
            'setting' => $model->find(1),
            'title'   => 'Pengaturan Aplikasi'
        ];
        return view('settings/index', $data);
    }

    public function update()
    {
        $model = new SettingsModel();
        $id = 1; // Selalu update ID 1
        $oldData = $model->find($id);

        // 1. Ambil Input Text
        $data = [
            'app_name'       => $this->request->getVar('app_name'),
            'school_name'    => $this->request->getVar('school_name'),
            'school_address' => $this->request->getVar('school_address'),
        ];

        // 2. Handle Upload Logo Aplikasi
        $fileAppLogo = $this->request->getFile('app_logo');
        if ($fileAppLogo && $fileAppLogo->isValid() && !$fileAppLogo->hasMoved()) {
            // Hapus file lama jika bukan default
            if ($oldData['app_logo'] != 'default_logo.png') {
                $path = FCPATH . 'uploads/settings/' . $oldData['app_logo'];
                if (file_exists($path)) unlink($path);
            }
            // Upload baru
            $newName = $fileAppLogo->getRandomName();
            $fileAppLogo->move(FCPATH . 'uploads/settings', $newName);
            $data['app_logo'] = $newName;
        }

        // 3. Handle Upload Logo QR Code
        $fileQrLogo = $this->request->getFile('qr_logo');
        if ($fileQrLogo && $fileQrLogo->isValid() && !$fileQrLogo->hasMoved()) {
            // Hapus file lama
            if ($oldData['qr_logo'] != 'default_qr_logo.png') {
                $path = FCPATH . 'uploads/settings/' . $oldData['qr_logo'];
                if (file_exists($path)) unlink($path);
            }
            // Upload baru
            $newName = $fileQrLogo->getRandomName();
            $fileQrLogo->move(FCPATH . 'uploads/settings', $newName);
            $data['qr_logo'] = $newName;
        }

        $model->update($id, $data);
        return redirect()->to('/settings')->with('success', 'Pengaturan berhasil diperbarui.');
    }
}