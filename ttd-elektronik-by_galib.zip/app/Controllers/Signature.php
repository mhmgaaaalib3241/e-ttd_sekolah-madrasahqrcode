<?php namespace App\Controllers;

use App\Models\DocumentModel;
use App\Models\SignatureModel;
use setasign\Fpdi\Fpdi;

use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;

class Signature extends BaseController {
    
    public function editor($id) {
        $model = new DocumentModel();
        $data['doc'] = $model->find($id);
        
        if(!$data['doc']) {
            return redirect()->to('/documents')->with('error', 'Dokumen tidak ditemukan');
        }

        return view('signature/editor', $data);
    }

    // 1. Generate QR Code (FIX: TRANSPARAN)
    public function generate_qr() {
        if (file_exists(ROOTPATH . 'vendor/autoload.php')) {
            require_once ROOTPATH . 'vendor/autoload.php';
        }

        $hash = md5(uniqid(rand(), true));
        $verifyUrl = base_url("verify/" . $hash);
        $qrName = $hash . '.png';
        
        $path = FCPATH . 'uploads/qr/';
        if (!is_dir($path)) mkdir($path, 0777, true);

        // AMBIL LOGO
        $db = \Config\Database::connect();
        $setting = $db->table('settings')->where('id', 1)->get()->getRowArray();
        
        $logoPath = null;
        if ($setting && !empty($setting['qr_logo'])) {
            $checkPath = FCPATH . 'uploads/settings/' . $setting['qr_logo'];
            if (file_exists($checkPath)) $logoPath = $checkPath;
        }

        try {
            $options = new QROptions([
                'version'          => QRCode::VERSION_AUTO,
                'outputType'       => QRCode::OUTPUT_IMAGE_PNG,
                'eccLevel'         => QRCode::ECC_H,
                'scale'            => 10,
                
                // TRANSPARANSI AGAR TIDAK KOTAK PUTIH
                'imageBase64'      => false,
                'imageTransparent' => true, 
                'transparencyColor' => [255, 255, 255], 
            ]);

            $qrcode = new QRCode($options);
            $qrcode->render($verifyUrl, $path . $qrName);

            // TEMPEL LOGO
            if ($logoPath) {
                $qrImage = imagecreatefrompng($path . $qrName);
                
                $logoInfo = getimagesize($logoPath);
                $logoMime = $logoInfo['mime'];
                
                $logoImage = null;
                if ($logoMime == 'image/png') $logoImage = imagecreatefrompng($logoPath);
                elseif ($logoMime == 'image/jpeg') $logoImage = imagecreatefromjpeg($logoPath);

                if ($logoImage && $qrImage) {
                    $qrWidth = imagesx($qrImage);
                    $qrHeight = imagesy($qrImage);
                    $logoWidth = imagesx($logoImage);
                    $logoHeight = imagesy($logoImage);

                    $newLogoWidth = $qrWidth * 0.2;
                    $scale = $newLogoWidth / $logoWidth;
                    $newLogoHeight = $logoHeight * $scale;
                    $x = ($qrWidth - $newLogoWidth) / 2;
                    $y = ($qrHeight - $newLogoHeight) / 2;

                    imagealphablending($logoImage, true);
                    imagecopyresampled($qrImage, $logoImage, $x, $y, 0, 0, $newLogoWidth, $newLogoHeight, $logoWidth, $logoHeight);
                    
                    imagepng($qrImage, $path . $qrName);
                    
                    imagedestroy($qrImage);
                    imagedestroy($logoImage);
                }
            }

            return $this->response->setJSON([
                'status' => 'success',
                'qr_url' => base_url('uploads/qr/' . $qrName),
                'qr_file' => $path . $qrName,
                'hash' => $hash
            ]);

        } catch (\Exception $e) {
            return $this->response->setJSON(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    // 2. Simpan Posisi (FIX: POSISI AKURAT & FOOTER)
    public function save_position() {
        $docId = $this->request->getVar('doc_id');
        $model = new DocumentModel();
        $doc = $model->find($docId);

        if (!$doc) return $this->response->setJSON(['status' => 'error', 'message' => 'Dokumen hilang']);

        $db = \Config\Database::connect();
        $setting = $db->table('settings')->where('id', 1)->get()->getRowArray();
        $namaSekolah = $setting['school_name'] ?? 'MIS AS-SUNNAH DARUN NAJIYAH';

        $sourcePdf = FCPATH . 'uploads/original/' . $doc['file_path'];
        $outputPdfName = 'SIGNED_' . $doc['file_path'];
        $outputPdfPath = FCPATH . 'uploads/signed/' . $outputPdfName;
        
        if (!is_dir(FCPATH . 'uploads/signed/')) mkdir(FCPATH . 'uploads/signed/', 0777, true);

        $qrPath = $this->request->getVar('qr_path_server');
        
        // --- TERIMA INPUT PERSENTASE (0.1 - 1.0) ---
        $xPerc = $this->request->getVar('x'); 
        $yPerc = $this->request->getVar('y');
        $wPerc = $this->request->getVar('w'); // Lebar (Resize)

        if(!file_exists($qrPath)) return $this->response->setJSON(['status' => 'error', 'message' => 'QR hilang.']);

        $pdf = new Fpdi();
        
        try {
            $pageCount = $pdf->setSourceFile($sourcePdf);
        } catch (\Exception $e) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'PDF Error: ' . $e->getMessage()]);
        }

        $pdf->SetAutoPageBreak(false);

        for ($i = 1; $i <= $pageCount; $i++) {
            $tplIdx = $pdf->importPage($i);
            
            // AMBIL UKURAN ASLI HALAMAN
            $size = $pdf->getTemplateSize($tplIdx);
            $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
            
            // BUAT HALAMAN SESUAI UKURAN ASLI
            $pdf->AddPage($orientation, [$size['width'], $size['height']]);
            $pdf->useTemplate($tplIdx, 0, 0, $size['width'], $size['height'], false);

            if ($i == 1) {
                // --- RUMUS PERBAIKAN POSISI ---
                // Persentase x Ukuran Asli Kertas = Posisi Milimeter Pasti
                $finalX = $size['width'] * $xPerc;
                $finalY = $size['height'] * $yPerc;
                
                // Hitung Lebar QR
                $finalW = ($wPerc) ? ($size['width'] * $wPerc) : 25; 

                // Tempel QR
                $pdf->Image($qrPath, $finalX, $finalY, $finalW);

                // --- TEMPEL FOOTER (CATATAN KAKI) ---
                $pdf->SetFont('Arial', 'I', 7); 
                $pdf->SetTextColor(0, 0, 0); 

                $marginLeft = 15;
                $lineHeight = 3; 
                $yPos = $size['height'] - 30; 
                $pdf->SetXY($marginLeft, $yPos);

                $pdf->Cell(0, $lineHeight, 'Catatan :', 0, 1, 'L');
                
                $pdf->SetX($marginLeft); 
                $pdf->Cell(0, $lineHeight, "- UU ITE No. 11 Tahun 2008 Pasal 5 ayat 1 'Informasi Elektronik dan/atau hasil", 0, 1, 'L');
                $pdf->SetX($marginLeft + 2); 
                $pdf->Cell(0, $lineHeight, "cetaknya merupakan alat bukti yang sah.'", 0, 1, 'L');

                $pdf->SetX($marginLeft);
                $pdf->Cell(0, $lineHeight, "- Dokumen ini telah ditandatangani secara elektronik menggunakan", 0, 1, 'L');
                $pdf->SetX($marginLeft + 2);
                $pdf->Cell(0, $lineHeight, "Aplikasi Sertifikat Elektronik " . $namaSekolah, 0, 1, 'L');

                $pdf->SetX($marginLeft);
                $pdf->Cell(0, $lineHeight, "- Surat ini dapat dibuktikan keasliannya dengan melakukan scan pada QR Code.", 0, 1, 'L');
            }
        }

        $pdf->Output('F', $outputPdfPath);

        $sigModel = new SignatureModel();
        $sigModel->save([
            'document_id' => $docId,
            'signer_name' => $this->request->getVar('signer_name'),
            'nip_npk' => $this->request->getVar('nip'),
            'jabatan' => $this->request->getVar('jabatan'),
            'tgl_ttd' => $this->request->getVar('tgl_ttd'),
            'unique_hash' => $this->request->getVar('hash'),
            'qr_code_path' => $outputPdfName
        ]);
        $model->update($docId, ['status' => 'signed', 'signed_file_path' => $outputPdfName]);

        return $this->response->setJSON(['status' => 'success']);
    }
}