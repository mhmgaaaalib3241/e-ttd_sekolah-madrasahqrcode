<?php namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        $model = new UserModel();
        
        // Urutkan user terbaru di atas
        $data = [
            'users' => $model->orderBy('created_at', 'DESC')->findAll(),
            'title' => 'Manajemen Users'
        ];

        return view('users/index', $data);
    }

    public function store()
    {
        $model = new UserModel();

        // Ambil Data
        $data = [
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'username'     => $this->request->getVar('username'),
            'role'         => $this->request->getVar('role'),
            // Hash Password
            'password'     => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
        ];

        $model->save($data);
        return redirect()->to('/users')->with('success', 'User baru berhasil ditambahkan.');
    }

    public function update()
    {
        $model = new UserModel();
        $id = $this->request->getVar('id');

        $data = [
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'username'     => $this->request->getVar('username'),
            'role'         => $this->request->getVar('role'),
        ];

        // Cek apakah password diisi? Jika ya, update password baru.
        // Jika kosong, biarkan password lama.
        $passInput = $this->request->getVar('password');
        if (!empty($passInput)) {
            $data['password'] = password_hash($passInput, PASSWORD_DEFAULT);
        }

        $model->update($id, $data);
        return redirect()->to('/users')->with('success', 'Data user berhasil diperbarui.');
    }

    public function delete($id)
    {
        $model = new UserModel();
        $model->delete($id);
        return redirect()->to('/users')->with('success', 'User berhasil dihapus.');
    }
}