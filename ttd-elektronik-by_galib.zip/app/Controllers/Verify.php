<?php namespace App\Controllers;

use App\Models\SignatureModel;
use App\Models\DocumentModel;

class Verify extends BaseController {

    public function index($hash = null) {
        if ($hash == null) {
            return "Kode Hash tidak valid.";
        }

        $db = \Config\Database::connect();
        
        // Kita gunakan Query Builder agar bisa JOIN tabel signatures dan documents
        // untuk mengambil detail dokumennya sekalian.
        $builder = $db->table('signatures');
        $builder->select('signatures.*, documents.nomor_surat, documents.nama_berkas, documents.signed_file_path');
        $builder->join('documents', 'documents.id = signatures.document_id');
        $builder->where('signatures.unique_hash', $hash);
        
        $query = $builder->get();
        $result = $query->getRowArray(); // Ambil 1 baris data

        $data = [
            'found' => ($result != null), // True jika data ada
            'data'  => $result,
            'hash'  => $hash
        ];

        return view('verification_result', $data);
    }
}