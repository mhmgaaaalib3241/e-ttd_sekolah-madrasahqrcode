<?php

namespace App\Models;

use CodeIgniter\Model;

class DocumentModel extends Model
{
    protected $table            = 'documents';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    
    // Kolom yang boleh diisi oleh sistem
    protected $allowedFields    = [
        'nomor_surat', 
        'nama_berkas', 
        'file_path', 
        'uploader_name', 
        'tanggal_berkas', 
        'status', 
        'signed_file_path'
    ];

    // Aktifkan timestamp agar created_at otomatis terisi
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = ''; // Kita tidak pakai updated_at
}