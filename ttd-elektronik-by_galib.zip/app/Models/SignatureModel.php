<?php

namespace App\Models;

use CodeIgniter\Model;

class SignatureModel extends Model
{
    protected $table            = 'signatures';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields    = [
        'document_id', 
        'signer_name', 
        'nip_npk', 
        'jabatan', 
        'tgl_ttd', 
        'qr_code_path', 
        'unique_hash'
    ];
}