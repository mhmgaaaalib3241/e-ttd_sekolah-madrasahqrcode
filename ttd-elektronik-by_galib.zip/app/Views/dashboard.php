<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

<style>
    /* Styling Khusus Dashboard */
    .welcome-banner {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
        color: white;
        border-radius: 20px;
        padding: 40px;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 25px rgba(78, 115, 223, 0.3);
    }
    
    /* Hiasan lingkaran background */
    .welcome-banner::before {
        content: '';
        position: absolute;
        top: -50px; right: -50px;
        width: 200px; height: 200px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .welcome-banner::after {
        content: '';
        position: absolute;
        bottom: -30px; left: 50px;
        width: 100px; height: 100px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }

    .stat-card {
        border: none;
        border-radius: 15px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background: white;
        overflow: hidden;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.08);
    }

    .icon-box {
        width: 50px; height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    .action-card {
        background: white;
        border: 1px solid #eee;
        border-radius: 15px;
        padding: 25px;
        text-decoration: none;
        color: inherit;
        display: block;
        transition: all 0.3s;
        height: 100%;
    }

    .action-card:hover {
        background: white;
        border-color: #4e73df;
        box-shadow: 0 5px 15px rgba(78, 115, 223, 0.15);
        color: #4e73df;
    }
    
    .action-card:hover p { color: #858796; } /* Jaga deskripsi tetap abu */

    .action-icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        display: inline-block;
    }
</style>

<div class="row mb-5 fade-in">
    <div class="col-12">
        <div class="welcome-banner">
            <div class="position-relative">
                <h2 class="fw-bold mb-1">Dashboard Ikhtisar</h2>
                <p class="mb-0 opacity-75">Selamat datang kembali, <strong><?= session()->get('nama'); ?></strong>! Berikut adalah laporan aktivitas sistem Anda hari ini.</p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-5 fade-in">
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100 p-3">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted text-uppercase fw-bold small mb-1">Total Pengguna</h6>
                    <h2 class="mb-0 fw-bold text-dark"><?= $count_users ?></h2>
                </div>
                <div class="icon-box bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-people-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100 p-3">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted text-uppercase fw-bold small mb-1">Berkas Masuk</h6>
                    <h2 class="mb-0 fw-bold text-dark"><?= $count_docs ?></h2>
                    <?php if($pending_docs > 0): ?>
                        <span class="badge bg-warning text-dark mt-2">
                            <i class="bi bi-exclamation-circle me-1"></i> <?= $pending_docs ?> Pending
                        </span>
                    <?php else: ?>
                        <span class="badge bg-success mt-2">All Clear</span>
                    <?php endif; ?>
                </div>
                <div class="icon-box bg-success bg-opacity-10 text-success">
                    <i class="bi bi-file-earmark-text-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100 p-3">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-muted text-uppercase fw-bold small mb-1">Total Tanda Tangan</h6>
                    <h2 class="mb-0 fw-bold text-dark"><?= $count_ttd ?></h2>
                </div>
                <div class="icon-box bg-warning bg-opacity-10 text-warning">
                    <i class="bi bi-qr-code-scan"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<h5 class="fw-bold mb-3 ps-2 border-start border-4 border-primary">Akses Cepat</h5>
<div class="row g-4 fade-in">
    <div class="col-md-4">
        <a href="<?= base_url('documents') ?>" class="action-card">
            <div class="action-icon text-primary">
                <i class="bi bi-cloud-arrow-up-fill"></i>
            </div>
            <h5 class="fw-bold">Upload Berkas</h5>
            <p class="small text-muted mb-0">Unggah dokumen PDF baru untuk diproses tanda tangan digital.</p>
        </a>
    </div>
    
    <div class="col-md-4">
        <a href="<?= base_url('documents') ?>" class="action-card">
            <div class="action-icon text-success">
                <i class="bi bi-pen-fill"></i>
            </div>
            <h5 class="fw-bold">Proses Tanda Tangan</h5>
            <p class="small text-muted mb-0">Bubuhkan QR Code dan tanda tangani dokumen yang statusnya pending.</p>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?= base_url('users') ?>" class="action-card">
            <div class="action-icon text-dark">
                <i class="bi bi-person-fill-gear"></i>
            </div>
            <h5 class="fw-bold">Kelola Users</h5>
            <p class="small text-muted mb-0">Tambah admin baru atau kelola data pengguna aplikasi.</p>
        </a>
    </div>
</div>

<?= $this->endSection() ?>