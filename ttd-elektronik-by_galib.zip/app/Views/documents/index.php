<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
    /* --- MODERN TABLE STYLING --- */
    .table-card {
        border: none;
        border-radius: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        overflow: hidden;
        background: white;
    }
    
    .table thead th {
        background-color: #f8f9fa;
        color: #8898aa;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.05em;
        padding: 1.2rem 1.5rem;
        border-bottom: 1px solid #e9ecef;
    }

    .table tbody td {
        vertical-align: middle;
        padding: 1rem 1.5rem;
        color: #525f7f;
        border-bottom: 1px solid #e9ecef;
        font-size: 0.95rem;
    }

    /* --- ICONS & AVATARS --- */
    .icon-shape {
        width: 45px; height: 45px;
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.5rem; transition: transform 0.2s;
    }
    .row-file-item:hover .icon-shape { transform: scale(1.1); }

    .avatar-circle {
        width: 35px; height: 35px; border-radius: 50%;
        background-color: #e9ecef; color: #525f7f;
        display: flex; align-items: center; justify-content: center;
        font-weight: 700; font-size: 0.8rem;
        border: 2px solid #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    /* --- TOMBOL AKSI BERJEJER (BARU) --- */
    .btn-action-group .btn {
        width: 35px; height: 35px;
        padding: 0;
        display: inline-flex; align-items: center; justify-content: center;
        border-radius: 8px;
        margin-left: 5px;
        transition: all 0.2s;
    }
    .btn-action-group .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 10px rgba(0,0,0,0.1);
    }

    /* --- MODAL STYLING --- */
    .modal-content { border: none; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.2); }
    .form-control-upload {
        border: 2px dashed #dee2e6; background-color: #f8f9fa;
        padding: 3rem 1rem; text-align: center; border-radius: 15px;
        transition: all 0.3s; cursor: pointer;
    }
    .form-control-upload:hover { border-color: #5e72e4; background-color: #fff; }
</style>

<div class="d-flex justify-content-between align-items-end mb-4 fade-in">
    <div>
        <h6 class="text-uppercase text-muted small fw-bold mb-1 ls-1">Overview</h6>
        <h2 class="fw-bold text-dark mb-0">Manajemen Berkas</h2>
    </div>
    <button class="btn btn-primary shadow-sm px-4 py-2 rounded-pill" data-bs-toggle="modal" data-bs-target="#uploadModal">
        <i class="bi bi-plus-lg me-2"></i>Upload Baru
    </button>
</div>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success border-0 shadow-sm bg-white border-start border-4 border-success fade-in mb-4 d-flex align-items-center">
        <i class="bi bi-check-circle-fill text-success fs-4 me-3"></i>
        <div><h6 class="fw-bold mb-0 text-dark">Berhasil!</h6><div class="text-muted small"><?= session()->getFlashdata('success') ?></div></div>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger border-0 shadow-sm bg-white border-start border-4 border-danger fade-in mb-4 d-flex align-items-center">
        <i class="bi bi-exclamation-triangle-fill text-danger fs-4 me-3"></i>
        <div><h6 class="fw-bold mb-0 text-dark">Gagal!</h6><div class="text-muted small"><?= session()->getFlashdata('error') ?></div></div>
    </div>
<?php endif; ?>

<div class="card table-card fade-in">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Berkas</th>
                    <th>Detail Surat</th>
                    <th>Uploader</th>
                    <th>Status</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($docs)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="py-5">
                                <div class="bg-light rounded-circle d-inline-flex p-4 mb-3">
                                    <i class="bi bi-folder2-open text-muted" style="font-size: 3rem;"></i>
                                </div>
                                <h5 class="fw-bold text-dark">Belum ada berkas</h5>
                                <button class="btn btn-outline-primary btn-sm rounded-pill px-4 mt-2" data-bs-toggle="modal" data-bs-target="#uploadModal">Upload Sekarang</button>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach($docs as $d): ?>
                    <tr class="row-file-item">
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="icon-shape bg-primary bg-opacity-10 text-primary me-3">
                                    <i class="bi bi-file-earmark-pdf-fill"></i>
                                </div>
                                <div>
                                    <span class="d-block fw-bold text-dark text-truncate" style="max-width: 250px;">
                                        <?= esc($d['nama_berkas']) ?>
                                    </span>
                                    <small class="text-muted"><i class="bi bi-clock me-1"></i> <?= date('d/m/Y', strtotime($d['tanggal_berkas'])) ?></small>
                                </div>
                            </div>
                        </td>

                        <td>
                            <span class="d-block text-dark fw-semibold"><?= esc($d['nomor_surat']) ?></span>
                            <small class="text-muted">ID: #<?= $d['id'] ?></small>
                        </td>

                        <td>
                            <div class="d-flex align-items-center">
                                <?php 
                                    $colors = ['bg-info', 'bg-success', 'bg-warning', 'bg-danger', 'bg-primary'];
                                    $idx = crc32($d['uploader_name']) % count($colors);
                                ?>
                                <div class="avatar-circle <?= $colors[$idx] ?> text-white me-2">
                                    <?= strtoupper(substr($d['uploader_name'], 0, 1)) ?>
                                </div>
                                <span class="fw-semibold small"><?= esc($d['uploader_name']) ?></span>
                            </div>
                        </td>

                        <td>
                            <?php if($d['status'] == 'pending'): ?>
                                <span class="badge bg-warning bg-opacity-10 text-warning rounded-pill px-3">Pending</span>
                            <?php else: ?>
                                <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Signed</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-end pe-4">
                            <div class="btn-action-group">
                                
                                <?php if($d['status'] == 'pending'): ?>
                                    <a href="<?= base_url('documents/sign/'.$d['id']) ?>" class="btn btn-primary" title="Proses Tanda Tangan">
                                        <i class="bi bi-pen-fill"></i>
                                    </a>

                                    <button class="btn btn-warning text-white" title="Edit Data" onclick="editDoc('<?= $d['id'] ?>', '<?= $d['nomor_surat'] ?>', '<?= $d['nama_berkas'] ?>', '<?= $d['tanggal_berkas'] ?>')">
                                        <i class="bi bi-pencil-square"></i>
                                    </button>

                                    <a href="<?= base_url('uploads/original/'.$d['file_path']) ?>" target="_blank" class="btn btn-light border" title="Lihat File Asli">
                                        <i class="bi bi-eye"></i>
                                    </a>

                                    <a href="<?= base_url('documents/delete/'.$d['id']) ?>" class="btn btn-danger bg-opacity-10 text-danger border-0" title="Hapus Dokumen" onclick="return confirm('Hapus permanen dokumen ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>

                                <?php else: ?>
                                    <a href="<?= base_url('uploads/signed/'.$d['signed_file_path']) ?>" target="_blank" class="btn btn-success" title="Download Hasil TTD">
                                        <i class="bi bi-download"></i>
                                    </a>

                                    <a href="<?= base_url('uploads/original/'.$d['file_path']) ?>" target="_blank" class="btn btn-light border" title="Lihat File Asli">
                                        <i class="bi bi-eye"></i>
                                    </a>

                                    <a href="<?= base_url('documents/cancel/'.$d['id']) ?>" class="btn btn-outline-danger" title="Batalkan Tanda Tangan" onclick="return confirm('Batalkan TTD? Status kembali ke Pending.')">
                                        <i class="bi bi-x-lg"></i>
                                    </a>

                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold text-dark">Upload Dokumen Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= base_url('documents/upload') ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body p-4">
                    <div class="form-floating mb-3">
                        <input type="text" name="nomor_surat" class="form-control rounded-3" placeholder="No Surat" required>
                        <label class="text-muted">Nomor Surat</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="nama_berkas" class="form-control rounded-3" placeholder="Nama" required>
                        <label class="text-muted">Nama Berkas / Perihal</label>
                    </div>
                    <div class="form-floating mb-4">
                        <input type="date" name="tanggal_berkas" class="form-control rounded-3" value="<?= date('Y-m-d') ?>" required>
                        <label class="text-muted">Tanggal</label>
                    </div>
                    
                    <div class="mb-2">
                        <label class="form-label small fw-bold text-muted ms-1">File Dokumen (PDF)</label>
                        <input type="file" name="berkas" class="form-control form-control-upload" accept="application/pdf" required>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">Simpan Dokumen</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold text-primary">Edit Metadata</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= base_url('documents/update') ?>" method="post">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body p-4">
                    <div class="alert alert-primary bg-primary bg-opacity-10 border-0 small mb-3">
                        <i class="bi bi-info-circle-fill me-1"></i> File PDF tidak dapat diubah di sini.
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="nomor_surat" id="edit_nomor" class="form-control rounded-3" required>
                        <label class="text-muted">Nomor Surat</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="nama_berkas" id="edit_nama" class="form-control rounded-3" required>
                        <label class="text-muted">Nama Berkas</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="date" name="tanggal_berkas" id="edit_tanggal" class="form-control rounded-3" required>
                        <label class="text-muted">Tanggal</label>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function editDoc(id, nomor, nama, tanggal) {
        document.getElementById('edit_id').value = id;
        document.getElementById('edit_nomor').value = nomor;
        document.getElementById('edit_nama').value = nama;
        document.getElementById('edit_tanggal').value = tanggal;
        var myModal = new bootstrap.Modal(document.getElementById('editModal'));
        myModal.show();
    }
</script>

<?= $this->endSection() ?>