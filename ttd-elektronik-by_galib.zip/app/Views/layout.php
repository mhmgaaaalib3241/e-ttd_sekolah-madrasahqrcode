<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php 
        // 1. AMBIL SETTINGS DARI SESSION
        $settings = session()->get('app_settings'); 
        
        // 2. DETEKSI URL UNTUK MENU AKTIF
        $uri = service('uri');
        $current = $uri->getSegment(1); // ambil segment pertama (dashboard, documents, users, dll)
    ?>

    <title><?= !empty($settings['app_name']) ? esc($settings['app_name']) : 'Aplikasi TTD Digital' ?></title>
    
    <?php if(!empty($settings['app_logo']) && file_exists(FCPATH . 'uploads/settings/' . $settings['app_logo'])): ?>
        <link rel="icon" href="<?= base_url('uploads/settings/' . $settings['app_logo']) ?>">
    <?php else: ?>
        <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/1000/1000966.png" type="image/png">
    <?php endif; ?>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">

    <style>
        :root {
            --sidebar-width: 260px;
            --primary-gradient: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            --active-bg: rgba(255, 255, 255, 0.15);
            --bg-body: #f3f4f6;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-body);
            overflow-x: hidden;
        }

        /* --- 1. SIDEBAR STYLING --- */
        #sidebar-wrapper {
            min-height: 100vh;
            width: var(--sidebar-width);
            margin-left: 0;
            position: fixed;
            z-index: 1000;
            background: var(--primary-gradient);
            transition: margin .25s ease-out;
            color: white;
            box-shadow: 4px 0 15px rgba(0,0,0,0.1);
        }

        .sidebar-heading {
            padding: 1.5rem 1.25rem;
            font-size: 1.2rem;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
        }

        .list-group-item {
            border: none;
            padding: 12px 25px;
            background-color: transparent;
            color: rgba(255,255,255,0.8);
            font-weight: 500;
            transition: all 0.3s;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .list-group-item i {
            width: 25px;
            font-size: 1.1rem;
            margin-right: 5px;
            text-align: center;
        }

        .list-group-item:hover {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
            padding-left: 30px; /* Efek geser saat hover */
        }

        /* Menu Aktif */
        .list-group-item.active-menu {
            background-color: var(--active-bg);
            color: #fff;
            border-left: 4px solid #fff;
            font-weight: 600;
        }

        /* --- 2. CONTENT WRAPPER --- */
        #page-content-wrapper {
            width: 100%;
            margin-left: var(--sidebar-width);
            transition: margin .25s ease-out;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* --- 3. TOP NAVBAR --- */
        .top-navbar {
            background: white;
            padding: 0.8rem 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        /* --- 4. RESPONSIVE MOBILE --- */
        @media (max-width: 768px) {
            #sidebar-wrapper {
                margin-left: calc(-1 * var(--sidebar-width)); /* Sembunyi ke kiri */
            }
            #page-content-wrapper {
                margin-left: 0;
            }
            /* Class toggled untuk memunculkan sidebar */
            body.sb-sidenav-toggled #sidebar-wrapper {
                margin-left: 0;
            }
            body.sb-sidenav-toggled #page-content-wrapper {
                margin-left: 0; /* Content ditutup overlay */
            }
            /* Overlay Hitam saat sidebar muncul di HP */
            body.sb-sidenav-toggled #page-content-wrapper::before {
                content: "";
                position: fixed;
                top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 998;
            }
        }

        /* Utilities */
        .fade-in { animation: fadeIn 0.6s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .main-container { padding: 2rem; flex: 1; }
        .text-logo { letter-spacing: 1px; }
        
        /* Tombol Logout */
        .btn-logout {
            color: #e74a3b;
            font-weight: 600;
            padding: 5px 15px;
            border-radius: 20px;
            background: #fff5f5;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn-logout:hover { background: #e74a3b; color: white; }
    </style>
</head>
<body>

    <div class="d-flex" id="wrapper">
        
        <div id="sidebar-wrapper">
            <a href="<?= base_url('dashboard') ?>" class="sidebar-heading">
                <?php if(!empty($settings['app_logo']) && file_exists(FCPATH . 'uploads/settings/' . $settings['app_logo'])): ?>
                    <img src="<?= base_url('uploads/settings/' . $settings['app_logo']) ?>" width="35" class="me-2 rounded">
                <?php else: ?>
                    <i class="bi bi-pen-fill me-2"></i>
                <?php endif; ?>
                <span class="text-logo"><?= !empty($settings['app_name']) ? esc($settings['app_name']) : 'TTD DIGITAL' ?></span>
            </a>

            <div class="list-group list-group-flush mt-3">
                
                <small class="text-white-50 px-4 mb-2 text-uppercase" style="font-size: 0.75rem; letter-spacing: 1px;">Menu Utama</small>
                
                <a href="<?= base_url('dashboard') ?>" class="list-group-item <?= ($current == 'dashboard' || $current == '') ? 'active-menu' : '' ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                
                <a href="<?= base_url('documents') ?>" class="list-group-item <?= ($current == 'documents') ? 'active-menu' : '' ?>">
                    <i class="bi bi-folder2-open"></i> Berkas Masuk
                </a>
                
                <a href="<?= base_url('users') ?>" class="list-group-item <?= ($current == 'users') ? 'active-menu' : '' ?>">
                    <i class="bi bi-people"></i> Data Users
                </a>

                <div class="my-3 border-top border-light opacity-25"></div> <small class="text-white-50 px-4 mb-2 text-uppercase" style="font-size: 0.75rem; letter-spacing: 1px;">Sistem</small>

                <a href="<?= base_url('settings') ?>" class="list-group-item <?= ($current == 'settings') ? 'active-menu' : '' ?>">
                    <i class="bi bi-gear"></i> Pengaturan
                </a>
                
                <a href="<?= base_url('logout') ?>" class="list-group-item text-danger mt-3">
                    <i class="bi bi-box-arrow-left"></i> Logout
                </a>
            </div>
        </div>

        <div id="page-content-wrapper">
            
            <nav class="top-navbar">
                <button class="btn btn-light text-primary shadow-sm" id="sidebarToggle">
                    <i class="bi bi-list fs-5"></i>
                </button>

                <div class="d-flex align-items-center">
                    <div class="text-end me-3 d-none d-md-block">
                        <small class="text-muted d-block" style="font-size: 0.75rem;">Halo, Selamat Datang</small>
                        <span class="fw-bold text-dark"><?= session()->get('nama'); ?></span>
                    </div>
                    
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center shadow-sm" 
                         style="width: 40px; height: 40px; font-weight: bold;">
                        <?= strtoupper(substr(session()->get('nama'), 0, 1)) ?>
                    </div>
                </div>
            </nav>

            <div class="main-container fade-in">
                <?= $this->renderSection('content') ?>
            </div>

            <footer class="text-center py-3 text-muted small mt-auto">
                &copy; <?= date('Y') ?> <strong><?= !empty($settings['app_name']) ? esc($settings['app_name']) : 'TTD DIGITAL' ?></strong>. All rights reserved.
            </footer>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Logic Toggle Sidebar (Mobile & Desktop)
        window.addEventListener('DOMContentLoaded', event => {
            const sidebarToggle = document.body.querySelector('#sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', event => {
                    event.preventDefault();
                    document.body.classList.toggle('sb-sidenav-toggled');
                });
            }

            // Tutup sidebar jika klik area konten (Khusus Mobile)
            const pageContent = document.body.querySelector('#page-content-wrapper');
            pageContent.addEventListener('click', event => {
                if (window.innerWidth <= 768 && document.body.classList.contains('sb-sidenav-toggled')) {
                    document.body.classList.remove('sb-sidenav-toggled');
                }
            });
        });
    </script>

    <?= $this->renderSection('scripts') ?>
</body>
</html>