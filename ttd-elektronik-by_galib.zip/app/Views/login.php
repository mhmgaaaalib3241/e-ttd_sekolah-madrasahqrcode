<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - E-Signature System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); /* Gradasi Ungu-Biru Modern */
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
        }

        /* Efek Kartu Kaca (Glassmorphism) */
        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .card-header-custom {
            background: transparent;
            border-bottom: 0;
            padding: 20px 30px 0;
        }

        /* Styling Tabs */
        .nav-pills {
            background: #f1f3f5;
            padding: 5px;
            border-radius: 15px;
        }
        .nav-pills .nav-link {
            border-radius: 12px;
            color: #6c757d;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .nav-pills .nav-link.active {
            background-color: #fff;
            color: #764ba2;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        /* Form Input */
        .form-control {
            border-radius: 12px;
            padding: 12px 15px;
            border: 1px solid #e0e0e0;
            background-color: #f8f9fa;
        }
        .form-control:focus {
            background-color: #fff;
            border-color: #764ba2;
            box-shadow: 0 0 0 4px rgba(118, 75, 162, 0.1);
        }

        /* Tombol Utama */
        .btn-gradient {
            background: linear-gradient(to right, #667eea, #764ba2);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px;
            border-radius: 12px;
            transition: transform 0.2s;
        }
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(118, 75, 162, 0.4);
            color: white;
        }

        /* Custom Scanner Style */
        #reader {
            width: 100%;
            border-radius: 15px;
            overflow: hidden;
            border: 2px solid #f1f1f1;
            position: relative;
        }
        #reader video {
            object-fit: cover;
            border-radius: 15px;
        }
        /* Menyembunyikan elemen bawaan library yg jelek */
        #reader__scan_region img { display: none; } 
        #reader__dashboard_section_csr span { display: none; }

        .scan-overlay {
            position: relative;
        }
        .scan-frame {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            width: 200px; height: 200px;
            border: 2px dashed rgba(255,255,255,0.7);
            border-radius: 20px;
            pointer-events: none;
            z-index: 10;
            box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5); /* Efek gelap di luar kotak */
        }
        .brand-logo {
            font-size: 1.5rem;
            font-weight: 700;
            background: -webkit-linear-gradient(#667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                
                <div class="glass-card fade-in-up">
                    
                    <div class="text-center pt-4 pb-2">
                        <i class="bi bi-pen-fill fs-1 text-primary mb-2 d-block" style="background: -webkit-linear-gradient(#667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                        <div class="brand-logo">TTD Digital</div>
                        <p class="text-muted small">Sistem Tanda Tangan Elektronik</p>
                    </div>

                    <div class="card-header-custom">
                        <ul class="nav nav-pills nav-fill" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-login-tab" data-bs-toggle="pill" data-bs-target="#pills-login">
                                    <i class="bi bi-person-circle me-1"></i> Admin
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-cek-tab" data-bs-toggle="pill" data-bs-target="#pills-cek">
                                    <i class="bi bi-qr-code-scan me-1"></i> Scan QR
                                </button>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body p-4">
                        <div class="tab-content" id="pills-tabContent">
                            
                            <div class="tab-pane fade show active" id="pills-login">
                                <form action="<?= base_url('/auth/process') ?>" method="post">
                                    
                                    <?php if(session()->getFlashdata('error')): ?>
                                        <div class="alert alert-danger py-2 small rounded-3 border-0 bg-danger bg-opacity-10 text-danger mb-3">
                                            <i class="bi bi-exclamation-circle me-1"></i> <?= session()->getFlashdata('error') ?>
                                        </div>
                                    <?php endif; ?>

                                    <div class="mb-3">
                                        <label class="form-label small text-muted fw-bold ms-1">USERNAME</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-transparent border-end-0 rounded-start-3 ps-3 text-muted"><i class="bi bi-envelope"></i></span>
                                            <input type="text" name="username" class="form-control border-start-0 ps-0" placeholder="Masukkan username" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label small text-muted fw-bold ms-1">PASSWORD</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-transparent border-end-0 rounded-start-3 ps-3 text-muted"><i class="bi bi-lock"></i></span>
                                            <input type="password" name="password" class="form-control border-start-0 ps-0" placeholder="Masukkan password" required>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-gradient w-100 shadow-sm">
                                        Masuk Dashboard <i class="bi bi-arrow-right ms-1"></i>
                                    </button>
                                </form>
                                <div class="text-center mt-3">
                                    <small class="text-muted">Lupa password? Hubungi Administrator.</small>
                                </div>
                            </div>
                            
                            <div class="tab-pane fade" id="pills-cek">
                                
                                <div class="scan-overlay mb-3">
                                    <div id="reader"></div>
                                    <div id="scan-frame-visual" class="scan-frame" style="display:none;"></div> 
                                </div>

                                <div id="scan-status" class="text-center small text-muted mb-3">
                                    <i class="bi bi-camera-video"></i> Arahkan kamera ke QR Code
                                </div>

                                <div class="position-relative text-center my-3">
                                    <hr class="text-muted opacity-25">
                                    <span class="position-absolute top-50 start-50 translate-middle bg-white px-2 text-muted small">ATAU</span>
                                </div>

                                <div class="input-group">
                                    <input type="text" id="hashInput" class="form-control" placeholder="Kode Hash Manual">
                                    <button onclick="manualCheck()" class="btn btn-dark">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4 text-white opacity-75 small">
                    &copy; <?= date('Y') ?> Darun Najiyah. All Rights Reserved.
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function manualCheck() {
            let val = document.getElementById('hashInput').value;
            if(val) window.location.href = '<?= base_url('verify/') ?>' + val;
        }

        var html5QrcodeScanner = null;
        var isScannerActive = false;

        document.getElementById('pills-cek-tab').addEventListener('click', function() {
            if(!isScannerActive) {
                // Beri delay sedikit agar animasi tab selesai
                setTimeout(() => {
                    initScanner();
                }, 300);
            }
        });

        // Matikan scanner jika user pindah tab ke Login lagi (Hemat Baterai)
        document.getElementById('pills-login-tab').addEventListener('click', function() {
            if(html5QrcodeScanner) {
                html5QrcodeScanner.clear();
                isScannerActive = false;
                document.getElementById('scan-frame-visual').style.display = 'none';
            }
        });

        function initScanner() {
            // Tampilkan frame visual
            document.getElementById('scan-frame-visual').style.display = 'block';

            html5QrcodeScanner = new Html5QrcodeScanner(
                "reader", 
                { 
                    fps: 10, 
                    qrbox: {width: 250, height: 250},
                    aspectRatio: 1.0,
                    showTorchButtonIfSupported: true
                },
                false
            );

            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
            isScannerActive = true;
        }

        function onScanSuccess(decodedText, decodedResult) {
            console.log(`Scan Result: ${decodedText}`);
            
            // Audio Feedback (Beep)
            // let audio = new Audio('path/to/beep.mp3'); audio.play(); // Opsional

            // Hentikan scanner
            html5QrcodeScanner.clear();
            isScannerActive = false;
            
            document.getElementById('scan-status').innerHTML = '<span class="text-success fw-bold"><i class="bi bi-check-circle"></i> Berhasil! Mengalihkan...</span>';

            if(decodedText.includes('verify')) {
                window.location.href = decodedText;
            } else {
                alert("QR Code bukan milik dokumen TTD Digital ini.");
                window.location.reload();
            }
        }

        function onScanFailure(error) {
            // Kosongkan agar console bersih
        }
    </script>
</body>
</html>