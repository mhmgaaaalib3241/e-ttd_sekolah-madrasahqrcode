<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-end mb-4 fade-in">
    <div>
        <h6 class="text-uppercase text-muted small fw-bold mb-1 ls-1">Konfigurasi</h6>
        <h2 class="fw-bold text-dark mb-0">Pengaturan Sistem</h2>
    </div>
</div>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success border-0 shadow-sm bg-white border-start border-4 border-success fade-in mb-4">
        <i class="bi bi-check-circle-fill text-success me-2"></i> <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>

<form action="<?= base_url('settings/update') ?>" method="post" enctype="multipart/form-data">
    <div class="row fade-in">
        
        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white border-0 pt-4 px-4">
                    <h5 class="fw-bold text-primary"><i class="bi bi-building me-2"></i>Identitas Instansi</h5>
                </div>
                <div class="card-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-muted small">Nama Aplikasi (Di Navbar & Title)</label>
                        <input type="text" name="app_name" class="form-control rounded-3 py-2" value="<?= esc($setting['app_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-muted small">Nama Madrasah / Sekolah</label>
                        <input type="text" name="school_name" class="form-control rounded-3 py-2" value="<?= esc($setting['school_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-muted small">Alamat Lengkap</label>
                        <textarea name="school_address" class="form-control rounded-3" rows="3"><?= esc($setting['school_address']) ?></textarea>
                    </div>
                    <div class="text-end mt-4">
                        <button type="submit" class="btn btn-primary rounded-pill px-5 shadow-sm">
                            <i class="bi bi-save me-1"></i> Simpan Perubahan
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            
            <div class="card border-0 shadow-sm rounded-4 mb-4 text-center">
                <div class="card-body p-4">
                    <h6 class="fw-bold text-muted mb-3">Logo Aplikasi</h6>
                    <div class="mb-3 p-3 bg-light rounded-3">
                        <?php if($setting['app_logo'] && file_exists(FCPATH . 'uploads/settings/' . $setting['app_logo'])): ?>
                            <img src="<?= base_url('uploads/settings/' . $setting['app_logo']) ?>" class="img-fluid" style="max-height: 80px;">
                        <?php else: ?>
                            <span class="text-muted small fst-italic">Belum ada logo</span>
                        <?php endif; ?>
                    </div>
                    <input type="file" name="app_logo" class="form-control form-control-sm mt-2" accept="image/*">
                    <small class="text-muted" style="font-size: 0.75rem;">Format PNG/JPG. Max 2MB.</small>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 text-center">
                <div class="card-body p-4">
                    <h6 class="fw-bold text-muted mb-3">Logo Tengah QR Code</h6>
                    <div class="mb-3 p-3 bg-light rounded-3">
                        <?php if($setting['qr_logo'] && file_exists(FCPATH . 'uploads/settings/' . $setting['qr_logo'])): ?>
                            <img src="<?= base_url('uploads/settings/' . $setting['qr_logo']) ?>" class="img-fluid" style="max-height: 80px;">
                        <?php else: ?>
                            <span class="text-muted small fst-italic">Belum ada logo</span>
                        <?php endif; ?>
                    </div>
                    <input type="file" name="qr_logo" class="form-control form-control-sm mt-2" accept="image/*">
                    <small class="text-muted" style="font-size: 0.75rem;">Disarankan rasio 1:1 (Kotak). Background transparan.</small>
                </div>
            </div>

        </div>
    </div>
</form>

<?= $this->endSection() ?>