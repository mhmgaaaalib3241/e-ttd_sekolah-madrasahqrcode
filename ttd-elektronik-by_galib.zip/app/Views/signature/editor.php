<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<style>
    /* CSS RESIZE & DRAG */
    #pdf-wrapper { 
        position: relative; 
        border: 2px solid #333; 
        background-color: #525659; 
        overflow: hidden; 
        margin: 0 auto; 
        display: inline-block; 
    }
    #the-canvas { display: block; width: 100%; height: auto; }

    /* Kotak QR dengan Fitur Resize */
    .draggable-qr { 
        width: 100px; 
        height: 100px; 
        position: absolute; 
        top: 0; left: 0;
        cursor: grab; 
        border: 2px dashed #0d6efd; /* Biru agar terlihat */
        background-color: transparent; /* Transparan */
        z-index: 9999; 
        
        /* FITUR RESIZE */
        resize: both;
        overflow: hidden;
        min-width: 40px;
        max-width: 300px;
    }
    
    .draggable-qr:active { cursor: grabbing; border-color: #198754; }
    .draggable-qr img { width: 100%; height: 100%; pointer-events: none; }
    /* Container Utama: Relatif agar anak-anaknya bisa absolute terhadap ini */
    #pdf-wrapper { 
        position: relative; 
        border: 2px solid #333; 
        background-color: #525659; 
        overflow: hidden; 
        margin: 0 auto; 
        display: inline-block; /* Agar membungkus canvas dengan pas */
    }

    /* Canvas PDF */
    #the-canvas { 
        display: block; 
        width: 100%; 
        height: auto; 
    }

    /* Kotak QR Code yang bisa digeser */
    .draggable-qr { 
        width: 100px; 
        height: 100px; 
        position: absolute; /* Wajib Absolute */
        top: 0; left: 0;
        cursor: grab; 
        border: 2px dashed red; /* Garis bantu merah agar terlihat */
        background-color: rgba(255, 255, 255, 0.5); /* Semi transparan */
        display: none; /* Default sembunyi */
        z-index: 9999; /* PAKSA TAMPIL PALING DEPAN */
        touch-action: none; /* Fix untuk drag di layar sentuh */
    }

    .draggable-qr:active {
        cursor: grabbing;
        border-color: green;
    }

    .draggable-qr img { 
        width: 100%; 
        height: 100%; 
        pointer-events: none; /* Agar gambar tidak mengganggu drag event */
    }
</style>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">1. Data Penandatangan</h5>
                </div>
                <div class="card-body">
                    <form id="formGen">
                        <input type="hidden" name="doc_id" value="<?= $doc['id'] ?>">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Nama Lengkap</label>
                            <input type="text" name="signer_name" class="form-control" placeholder="Cth: Ahmad Fulan" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">NIP / NPK</label>
                            <input type="text" name="nip" class="form-control" placeholder="Cth: 198001..." required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Jabatan</label>
                            <input type="text" name="jabatan" class="form-control" placeholder="Cth: Kepala Madrasah" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Tanggal TTD</label>
                            <input type="date" name="tgl_ttd" class="form-control" required value="<?= date('Y-m-d') ?>">
                        </div>
                        <button type="button" onclick="generateQR()" class="btn btn-dark w-100" id="btnGenerate">
                            <i class="bi bi-qr-code"></i> Generate QR Code
                        </button>
                    </form>
                </div>
            </div>

            <div class="card shadow mt-3">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">2. Simpan Dokumen</h5>
                </div>
                <div class="card-body">
                    <p class="small text-muted">
                        <i class="bi bi-info-circle"></i> Setelah QR muncul (kotak merah), geser ke posisi yang diinginkan.
                    </p>
                    <button id="btnSave" onclick="finishSigning()" class="btn btn-success w-100 fw-bold" disabled>
                        <i class="bi bi-save"></i> Simpan & Tempel TTD
                    </button>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="<?= base_url('documents') ?>" class="btn btn-outline-secondary w-100">Kembali</a>
            </div>
        </div>

        <div class="col-md-9 text-center bg-light p-4 rounded shadow-sm" style="min-height: 600px;">
            <div id="loading-text" class="text-muted">Memuat PDF...</div>
            
            <div id="pdf-wrapper">
                <canvas id="the-canvas"></canvas>
                
                <div id="drag-qr" class="draggable-qr">
                    <img id="qr-img-src" src="" alt="QR Code">
                </div>
            </div>

        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"></script>

<script>
    // --- 1. SETUP PDF VIEWER ---
    var url = '<?= base_url('uploads/original/' . $doc['file_path']) ?>';
    var pdfDoc = null;
    var pageNum = 1;
    var scale = 1.0; // Zoom level (1.0 = 100%)
    var canvas = document.getElementById('the-canvas');
    var ctx = canvas.getContext('2d');
    
    // Variabel Global Data QR
    var qrServerPath = "";
    var currentHash = "";

    // Set Worker PDF.js
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js';

    // Load Dokumen
    pdfjsLib.getDocument(url).promise.then(function(pdfDoc_) {
        pdfDoc = pdfDoc_;
        document.getElementById('loading-text').style.display = 'none';
        renderPage(pageNum);
    }).catch(function(error) {
        document.getElementById('loading-text').innerHTML = '<span class="text-danger">Gagal memuat PDF: ' + error.message + '</span>';
        console.error('Error loading PDF:', error);
    });

    function renderPage(num) {
        pdfDoc.getPage(num).then(function(page) {
            // Kita atur scale sedikit lebih besar agar jelas
            var viewport = page.getViewport({scale: 1.2});
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            // Samakan ukuran wrapper dengan canvas
            $('#pdf-wrapper').css({width: viewport.width, height: viewport.height});

            var renderContext = { canvasContext: ctx, viewport: viewport };
            page.render(renderContext);
        });
    }

    // --- 2. GENERATE QR CODE ---
    function generateQR() {
        var btn = $('#btnGenerate');
        var formData = $('#formGen').serialize();
        
        // Validasi input
        if($('input[name="signer_name"]').val() == "") { alert("Isi Nama Penandatangan dulu!"); return; }

        btn.html('<span class="spinner-border spinner-border-sm"></span> Loading...').prop('disabled', true);

        $.post('<?= base_url("signature/generate_qr") ?>', formData, function(response){
            btn.html('<i class="bi bi-qr-code"></i> Generate QR Code').prop('disabled', false);

            if(response.status == 'success') {
                console.log("QR Berhasil: ", response);

                // A. Set Gambar Source (tambah time agar tidak cache)
                $('#qr-img-src').attr('src', response.qr_url + '?t=' + new Date().getTime());
                
                // B. Munculkan Kotak
                $('#drag-qr').css('display', 'block'); // Paksa display block
                $('#drag-qr').show(); 
                
                // C. Simpan data path
                qrServerPath = response.qr_file;
                currentHash = response.hash;
                
                // D. Aktifkan Tombol Simpan
                $('#btnSave').prop('disabled', false);
                
                alert("QR Code berhasil dibuat! Silakan geser kotak merah di gambar ke posisi tanda tangan.");
            } else {
                alert("Gagal: " + response.message);
            }
        }).fail(function() {
            btn.html('<i class="bi bi-qr-code"></i> Generate QR Code').prop('disabled', false);
            alert("Terjadi kesalahan server (Error 500). Cek Console Log.");
        });
    }

    // --- 3. DRAG & DROP LOGIC (INTERACT.JS) ---
    // Posisi X dan Y disimpan di atribut data-x dan data-y elemen HTML
    interact('.draggable-qr').draggable({
        listeners: {
            start (event) {
                // Saat mulai drag
            },
            move (event) {
                var target = event.target;
                
                // Ambil posisi terakhir (atau 0 jika belum ada)
                var x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
                var y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

                // Geser elemen menggunakan CSS Transform
                target.style.transform = 'translate(' + x + 'px, ' + y + 'px)';

                // Update posisi atribut
                target.setAttribute('data-x', x);
                target.setAttribute('data-y', y);
            }
        },
        modifiers: [
            interact.modifiers.restrictRect({
                restriction: 'parent', // Dibatasi di dalam #pdf-wrapper
                endOnly: true
            })
        ]
    });

    // --- 4. SIMPAN FINAL (LOGIKA HITUNG POSISI BARU) ---
    function finishSigning() {
        if(!confirm('Posisi dan Ukuran sudah pas? Dokumen akan disimpan permanen.')) return;

        $('#btnSave').html('<span class="spinner-border spinner-border-sm"></span> Menyimpan...').prop('disabled', true);

        // Ambil elemen
        var qrEl = document.getElementById('drag-qr');
        var wrapper = document.getElementById('pdf-wrapper');
        
        // Ambil Kotak Koordinat (Bounding Box)
        var qrRect = qrEl.getBoundingClientRect();
        var wrapRect = wrapper.getBoundingClientRect();

        // 1. Hitung Posisi Relatif (Jarak QR dari Pojok Kiri Atas Canvas)
        var relativeX = qrRect.left - wrapRect.left;
        var relativeY = qrRect.top - wrapRect.top;

        // 2. Hitung Lebar QR
        var currentW = qrRect.width;

        // 3. Ambil Ukuran Canvas
        var canvasW = wrapRect.width;
        var canvasH = wrapRect.height;

        // 4. Konversi ke Persentase (0.0 - 1.0)
        var xPct = relativeX / canvasW;
        var yPct = relativeY / canvasH;
        var wPct = currentW / canvasW;

        // Kirim ke Server
        $.post('<?= base_url("signature/save_position") ?>', {
            doc_id: $('input[name="doc_id"]').val(),
            signer_name: $('input[name="signer_name"]').val(),
            nip: $('input[name="nip"]').val(),
            jabatan: $('input[name="jabatan"]').val(),
            tgl_ttd: $('input[name="tgl_ttd"]').val(),
            
            qr_path_server: qrServerPath,
            hash: currentHash,
            
            // DATA PERSENTASE (PENTING)
            x: xPct, 
            y: yPct,
            w: wPct 

        }, function(res){
            if(res.status == 'success') {
                alert('Berhasil! Dokumen telah ditandatangani.');
                window.location.href = '<?= base_url("documents") ?>';
            } else {
                alert('Gagal: ' + res.message);
                $('#btnSave').html('<i class="bi bi-save"></i> Simpan & Tempel TTD').prop('disabled', false);
            }
        });
    }
</script>
<?= $this->endSection() ?>