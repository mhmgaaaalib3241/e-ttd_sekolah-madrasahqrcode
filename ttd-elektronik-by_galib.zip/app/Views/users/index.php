<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
    /* Menggunakan Style yang sama dengan Halaman Documents */
    .table-card { border: none; border-radius: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); overflow: hidden; background: white; }
    .table thead th { background-color: #f8f9fa; color: #8898aa; font-weight: 700; text-transform: uppercase; font-size: 0.75rem; padding: 1.2rem 1.5rem; border-bottom: 1px solid #e9ecef; }
    .table tbody td { vertical-align: middle; padding: 1rem 1.5rem; color: #525f7f; border-bottom: 1px solid #e9ecef; font-size: 0.95rem; }
    
    /* Avatar Style */
    .avatar-circle { width: 40px; height: 40px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1rem; box-shadow: 0 3px 6px rgba(0,0,0,0.1); }
    
    /* Button Action Group */
    .btn-action-group .btn { width: 35px; height: 35px; padding: 0; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; margin-left: 5px; transition: all 0.2s; }
    .btn-action-group .btn:hover { transform: translateY(-3px); box-shadow: 0 5px 10px rgba(0,0,0,0.1); }

    /* Badges */
    .badge-role-admin { background-color: #e0f2fe; color: #0369a1; padding: 5px 12px; border-radius: 20px; font-weight: 600; font-size: 0.8rem; }
    .badge-role-user { background-color: #f1f5f9; color: #475569; padding: 5px 12px; border-radius: 20px; font-weight: 600; font-size: 0.8rem; }
</style>

<div class="d-flex justify-content-between align-items-end mb-4 fade-in">
    <div>
        <h6 class="text-uppercase text-muted small fw-bold mb-1 ls-1">System Access</h6>
        <h2 class="fw-bold text-dark mb-0">Manajemen Users</h2>
    </div>
    <button class="btn btn-primary shadow-sm px-4 py-2 rounded-pill" data-bs-toggle="modal" data-bs-target="#addModal">
        <i class="bi bi-person-plus-fill me-2"></i>Tambah User
    </button>
</div>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success border-0 shadow-sm bg-white border-start border-4 border-success fade-in mb-4 d-flex align-items-center">
        <i class="bi bi-check-circle-fill text-success fs-4 me-3"></i>
        <div><h6 class="fw-bold mb-0 text-dark">Berhasil!</h6><div class="text-muted small"><?= session()->getFlashdata('success') ?></div></div>
    </div>
<?php endif; ?>

<div class="card table-card fade-in">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Nama Pengguna</th>
                    <th>Username</th>
                    <th>Role (Hak Akses)</th>
                    <th>Terdaftar Pada</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td class="ps-4">
                        <div class="d-flex align-items-center">
                            <?php 
                                // Generate warna acak
                                $colors = ['bg-primary', 'bg-success', 'bg-warning', 'bg-danger', 'bg-info', 'bg-dark'];
                                $idx = crc32($u['nama_lengkap']) % count($colors);
                            ?>
                            <div class="avatar-circle <?= $colors[$idx] ?> me-3">
                                <?= strtoupper(substr($u['nama_lengkap'], 0, 1)) ?>
                            </div>
                            <div>
                                <span class="d-block fw-bold text-dark"><?= esc($u['nama_lengkap']) ?></span>
                                <small class="text-muted">ID: #<?= $u['id'] ?></small>
                            </div>
                        </div>
                    </td>

                    <td class="fw-semibold text-primary">
                        @<?= esc($u['username']) ?>
                    </td>

                    <td>
                        <?php if($u['role'] == 'admin'): ?>
                            <span class="badge-role-admin"><i class="bi bi-shield-check me-1"></i> Administrator</span>
                        <?php else: ?>
                            <span class="badge-role-user"><i class="bi bi-person me-1"></i> Staff / User</span>
                        <?php endif; ?>
                    </td>

                    <td class="text-muted">
                        <i class="bi bi-calendar3 me-1"></i> <?= date('d M Y', strtotime($u['created_at'])) ?>
                    </td>

                    <td class="text-end pe-4">
                        <div class="btn-action-group">
                            <button class="btn btn-warning text-white" 
                                onclick="editUser('<?= $u['id'] ?>', '<?= $u['nama_lengkap'] ?>', '<?= $u['username'] ?>', '<?= $u['role'] ?>')"
                                title="Edit User">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            
                            <?php if(session()->get('id') != $u['id']): ?>
                                <a href="<?= base_url('users/delete/'.$u['id']) ?>" 
                                   class="btn btn-danger bg-opacity-10 text-danger border-0" 
                                   title="Hapus User"
                                   onclick="return confirm('Yakin hapus user ini? Akses login mereka akan hilang.')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            <?php else: ?>
                                <button class="btn btn-light text-muted" disabled title="Tidak bisa hapus akun sendiri">
                                    <i class="bi bi-lock-fill"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0 pt-4 px-4">
                <h5 class="modal-title fw-bold text-dark">Tambah User Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= base_url('users/store') ?>" method="post">
                <div class="modal-body p-4">
                    <div class="form-floating mb-3">
                        <input type="text" name="nama_lengkap" class="form-control rounded-3" placeholder="Nama" required>
                        <label>Nama Lengkap</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="username" class="form-control rounded-3" placeholder="User" required>
                        <label>Username (Login)</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" name="password" class="form-control rounded-3" placeholder="Pass" required>
                        <label>Password</label>
                    </div>
                    <div class="form-floating">
                        <select name="role" class="form-select rounded-3">
                            <option value="admin">Administrator</option>
                            <option value="staff">Staff / User Biasa</option>
                        </select>
                        <label>Role / Hak Akses</label>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">Simpan User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0 pt-4 px-4">
                <h5 class="modal-title fw-bold text-primary">Edit Data User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= base_url('users/update') ?>" method="post">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body p-4">
                    <div class="form-floating mb-3">
                        <input type="text" name="nama_lengkap" id="edit_nama" class="form-control rounded-3" required>
                        <label>Nama Lengkap</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="username" id="edit_username" class="form-control rounded-3" required>
                        <label>Username</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select name="role" id="edit_role" class="form-select rounded-3">
                            <option value="admin">Administrator</option>
                            <option value="staff">Staff / User Biasa</option>
                        </select>
                        <label>Role</label>
                    </div>
                    
                    <hr class="my-4 text-muted">
                    <p class="small text-muted mb-2"><i class="bi bi-lock"></i> Ganti Password (Opsional)</p>
                    <div class="form-floating">
                        <input type="password" name="password" class="form-control rounded-3" placeholder="Isi jika ingin ganti">
                        <label>Password Baru (Kosongkan jika tetap)</label>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function editUser(id, nama, username, role) {
        document.getElementById('edit_id').value = id;
        document.getElementById('edit_nama').value = nama;
        document.getElementById('edit_username').value = username;
        document.getElementById('edit_role').value = role;
        
        var myModal = new bootstrap.Modal(document.getElementById('editModal'));
        myModal.show();
    }
</script>

<?= $this->endSection() ?>