<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Dokumen Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; }
        .card-valid { border-top: 5px solid #198754; }
        .card-invalid { border-top: 5px solid #dc3545; }
        .info-label { color: #6c757d; font-size: 0.9rem; }
        .info-value { font-weight: 600; color: #333; }
    </style>
</head>
<body class="d-flex align-items-center min-vh-100 py-4">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                
                <div class="text-center mb-4">
                    <h4 class="fw-bold text-dark">E-Signature Verification</h4>
                </div>

                <?php if($found): ?>
                    <div class="card shadow-lg card-valid border-0 rounded-4">
                        <div class="card-body p-4 text-center">
                            
                            <div class="mb-3">
                                <span class="badge rounded-pill bg-success bg-opacity-10 text-success p-3">
                                    <i class="bi bi-patch-check-fill" style="font-size: 3rem;"></i>
                                </span>
                            </div>

                            <h3 class="text-success fw-bold mb-1">DOKUMEN ASLI</h3>
                            <p class="text-muted small">Terdaftar di database sistem kami.</p>
                            <p class="text-muted small">Pastikan Nama Surat/Berkas dan No. Surat Cocok !!</p>
                            <hr class="my-4 border-secondary border-opacity-10">

                            <div class="text-start">
                                <div class="mb-3">
                                    <div class="info-label">Nama Penandatangan</div>
                                    <div class="info-value fs-5"><?= esc($data['signer_name']) ?></div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="info-label">NIP/NPK</div>
                                        <div class="info-value"><?= esc($data['nip_npk']) ?></div>
                                    </div>
                                    <div class="col-6">
                                        <div class="info-label">Jabatan</div>
                                        <div class="info-value"><?= esc($data['jabatan']) ?></div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="info-label">Tanggal Tanda Tangan</div>
                                    <div class="info-value text-primary">
                                        <?= date('d F Y, H:i', strtotime($data['tgl_ttd'])) ?> WIB
                                    </div>
                                </div>

                                <div class="p-3 bg-light rounded border">
                                    <div class="info-label mb-1">Dokumen Terkait:</div>
                                    <div class="fw-bold text-dark"><?= esc($data['nama_berkas']) ?></div>
                                    <div class="small text-muted">No: <?= esc($data['nomor_surat']) ?></div>
                                </div>
                            </div>

                            <div class="mt-4">
                                <a href="<?= base_url('uploads/signed/' . $data['signed_file_path']) ?>" class="btn btn-success w-100 py-2 shadow-sm" target="_blank">
                                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Dokumen Asli
                                </a>
                            </div>

                        </div>
                        <div class="card-footer bg-white text-center py-3">
                            <small class="text-muted">Kode Hash: <br><code class="text-dark"><?= $hash ?></code></small>
                        </div>
                    </div>

                <?php else: ?>

                    <div class="card shadow-lg card-invalid border-0 rounded-4">
                        <div class="card-body p-5 text-center">
                            
                            <div class="mb-3">
                                <span class="badge rounded-pill bg-danger bg-opacity-10 text-danger p-3">
                                    <i class="bi bi-x-circle-fill" style="font-size: 3rem;"></i>
                                </span>
                            </div>

                            <h3 class="text-danger fw-bold">TIDAK VALID</h3>
                            <p class="text-muted">Maaf, QR Code ini tidak terdaftar di sistem kami atau dokumen telah dihapus.</p>
                            
                            <div class="alert alert-warning mt-4 text-start small">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                <strong>Peringatan Keamanan:</strong><br>
                                Jangan mempercayai isi dokumen fisik yang menyertakan QR Code ini. Kemungkinan dokumen tersebut palsu atau telah dimanipulasi.
                            </div>

                            <div class="mt-4">
                                <a href="<?= base_url() ?>" class="btn btn-outline-danger w-100">Kembali ke Beranda</a>
                            </div>

                        </div>
                        <div class="card-footer bg-white text-center py-3">
                            <small class="text-muted">Input Hash: <br><code><?= $hash ?></code></small>
                        </div>
                    </div>

                <?php endif; ?>

            </div>
        </div>
    </div>

</body>
</html>